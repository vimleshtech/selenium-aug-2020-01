package example;

public class Calc {

	public static void main(String[] args) {

		//declaration of variables
		int a,b,c;
		a =44;
		b =89;
		
		//addition 
		c =a+b;		
		System.out.println("sum of two values "+c); //message + value of c
	
		
		//substration 
		c =a-b;
		System.out.println("sub of two valeus "+c);
		
	}

}
